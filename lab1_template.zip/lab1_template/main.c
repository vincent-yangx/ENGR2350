//////////////////////////
// Lab 1
// ENGR-2350 S24
// Names: Yuanjia Zhang, Xianfei Yang
// Section: 2
// Side: B
// Seat: 37
//////////////////////////

#include "engr2350_msp432.h"
#include "lab1lib.h"

void GPIOInit();
void TestIO();
void ControlSystem();

uint8_t LEDFL = 0; // Two variables to store the state of
uint8_t LEDFR = 1; // the front left/right LEDs (on-car)
uint8_t ss=0;      //
uint8_t ss_pre=0;  // store the previous value of ss
uint8_t pb=0;
uint8_t bmp0=0;
uint8_t bmp1=0;
uint8_t bmp2=0;
uint8_t bmp3=0;
uint8_t bmp4=0;
uint8_t bmp5=0;
uint8_t start_status=0;


int main (void){

    SysInit(); // Basic car initialization
    init_Sequence(); // Initializes the Lab1Lib Driver
    GPIOInit();

    printf("\r\n\n"
           "===========\r\n"
           "Lab 1 Start\r\n"
           "===========\r\n");

    while(1){
//        TestIO(); // Used in Part A to test the IO

        ControlSystem(); // Used in Part B to implement the desired functionality
    }
}

void GPIOInit(){
    // Add initializations of inputs and outputs

    //input  initializations
    GPIO_setAsInputPin(GPIO_PORT_P3,GPIO_PIN5);// two external inputs
    GPIO_setAsInputPin(GPIO_PORT_P5,GPIO_PIN6);
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4,GPIO_PIN0|GPIO_PIN2|GPIO_PIN3);// bumper buttons setup
    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P4,GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);// bumper buttons setup

    //output initializations
    GPIO_setAsOutputPin(GPIO_PORT_P8,GPIO_PIN0);//LEDFL
    GPIO_setAsOutputPin(GPIO_PORT_P8,GPIO_PIN5);//LEDFR
    GPIO_setAsOutputPin(GPIO_PORT_P6,GPIO_PIN0);//BiLED1 left
    GPIO_setAsOutputPin(GPIO_PORT_P6,GPIO_PIN1);//BiLED1 right
    GPIO_setAsOutputPin(GPIO_PORT_P3,GPIO_PIN6|GPIO_PIN7);// on/off for both motors
    GPIO_setAsOutputPin(GPIO_PORT_P5,GPIO_PIN4|GPIO_PIN5);// directions for both motors

}

void GetInputs(){

    ss = GPIO_getInputPinValue(GPIO_PORT_P3, GPIO_PIN5); // get the input values
    pb = GPIO_getInputPinValue(GPIO_PORT_P5, GPIO_PIN6);
    bmp0 = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN0);
    bmp1 = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN2);
    bmp2 = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN3);
    bmp3 = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN5);
    bmp4 = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN6);
    bmp5 = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN7);

}

void toggle_led()// use LEDFR here
{
    LEDFR=!LEDFR;
    if(LEDFR)
    {
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5);
    }
    else
    {
        GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN5);
    }
    LEDFL=!LEDFL;
    if(LEDFL)
    {
        GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);
    }
    else
    {
       GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN0);
    }
}

void TestIO(){
    // Add printf statement(s) for testing inputs
    uint8_t cmd;
    // Example code for testing outputs
    while(1){
        uint8_t cmd = getchar();
        if(cmd == 'a'){
            GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN0);
            // Turn LEDL On
        }else if(cmd == 'z'){
            GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN0);
            // Turn LEDL Off
        }else if (cmd == 's'){
            GPIO_setOutputHighOnPin(GPIO_PORT_P8,GPIO_PIN5);
            // LEDFR On
        }else if (cmd == 'x'){
            GPIO_setOutputLowOnPin(GPIO_PORT_P8,GPIO_PIN5);
            // LEDFR off
        }else if (cmd == 'q'){
            GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN0);
            GPIO_setOutputLowOnPin(GPIO_PORT_P6,GPIO_PIN1);

            // BiLED1 Red
        }else if (cmd == 'w'){
            GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN1);
            GPIO_setOutputLowOnPin(GPIO_PORT_P6,GPIO_PIN0);
            // BiLED2 Off
        }else if (cmd == 'e'){
            GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN1|GPIO_PIN0);
            // BiLED1 Green
        }
    }
}

void ControlSystem(){
    while(1) {
        GetInputs();
        if (ss)// ss1 on
            {
                if(start_status==0)   //pattern not started
                {
                    if(ss_pre==1)   //initial ss1 is 1, not able to run
                    {
                        __delay_cycles(240e3);
                        start_status=0;
                    }
                    else
                    {
                        uint8_t op_run;
                        op_run = run_Sequence();
                        uint8_t len;
                        len=get_SequenceLength();
                        printf("The length is %d\n",len);
                        printf("The result of running sequence is %d\n",op_run);
                        start_status=1;
                    }
                }
                else       // not started
                {
                    uint8_t complete_status;
                    complete_status=status_Sequence();
                    if(complete_status==100)// completed
                    {
                        start_status=0;
                        GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN1);
                        GPIO_setOutputLowOnPin(GPIO_PORT_P6,GPIO_PIN0);
                        clear_Sequence();
                    }
                    else
                    {
                        GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN0);
                        GPIO_setOutputLowOnPin(GPIO_PORT_P6,GPIO_PIN1);
                    }
                }
            }
            else    // ss1 off
            {
                GPIO_setOutputHighOnPin(GPIO_PORT_P6,GPIO_PIN1|GPIO_PIN0);
                if(bmp0&&bmp1&&bmp2&&bmp3&&bmp4&&bmp5)//No bmp pressed
                {
                    if(pb)  //pb pressed
                    {
                        uint8_t sign;
                        sign=pop_Segment();
                        printf("The result of removing the most recently added segment is %d\n",sign);
                        __delay_cycles(240e3);
                    }
                    else    //pb not pressed
                    {
                        continue;
                    }
                }
                else    // any bmp pressed
                {
                    int8_t op;
                    if(!bmp0)   //bmp0 pressed
                    {
                        op=record_Segment(2);
                        while(1)
                        {
                            __delay_cycles(240e3);
                            uint8_t bmp0_detect;
                            bmp0_detect = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN0);
                            if(bmp0_detect==1)
                            {
                                __delay_cycles(240e3);
                                break;
                            }
                        }
                        printf("This is the result of record_seg:%d\n",op);
                    }
                    if(!bmp1)   //bmp1 pressed
                    {
                        op=record_Segment(1);
                        while(1)
                        {
                             __delay_cycles(240e3);
                             uint8_t bmp1_detect;
                             bmp1_detect = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN2);
                             if(bmp1_detect==1)
                             {
                                __delay_cycles(240e3);
                                break;
                             }
                        }
                        printf("This is the result of record_seg:%d\n",op);
                    }
                    if(!bmp2)   //bmp2 pressed
                    {
                        op=record_Segment(0);
                        while(1)
                        {
                            __delay_cycles(240e3);
                            uint8_t bmp2_detect;
                            bmp2_detect = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN3);
                            if(bmp2_detect==1)
                            {
                                 _delay_cycles(240e3);
                                 break;
                            }
                        }
                        printf("This is the result of record_seg:%d\n",op);
                    }
                    if(!bmp3)   //bmp3 pressed
                    {
                        op=record_Segment(127);
                        while(1)
                        {
                              __delay_cycles(240e3);
                              uint8_t bmp3_detect;
                              bmp3_detect = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN5);
                              if(bmp3_detect==1)
                              {
                                     _delay_cycles(240e3);
                                     break;
                              }
                         }
                        printf("This is the result of record_seg:%d\n",op);
                    }
                    if(!bmp4)   //bmp4 pressed
                    {
                        op=record_Segment(-1);
                        while(1)
                        {
                              __delay_cycles(240e3);
                              uint8_t bmp4_detect;
                              bmp4_detect = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN6);
                              if(bmp4_detect==1)
                              {
                                    _delay_cycles(240e3);
                                    break;
                              }
                         }
                        printf("This is the result of record_seg:%d\n",op);
                    }
                    if(!bmp5)   //bmp5 pressed
                    {
                        op=record_Segment(-2);
                        while(1)
                        {
                              __delay_cycles(240e3);
                              uint8_t bmp5_detect;
                              bmp5_detect = GPIO_getInputPinValue(GPIO_PORT_P4, GPIO_PIN7);
                              if(bmp5_detect==1)
                              {
                                     _delay_cycles(240e3);
                                     break;
                               }
                         }
                        printf("This is the result of record_seg:%d\n",op);
                    }
                    toggle_led();
                    __delay_cycles(240e3);
                }
            }
        ss_pre=ss;  // update ss
    }

}
